package com.seller.entity;

public class SearchItem {
	private String searchItems;
	

	public SearchItem() {
		
		
	}

	public String getSearchItems() {
		return searchItems;
	}

	public void setSearchItems(String searchItems) {
		this.searchItems = searchItems;
	}

	public SearchItem(String searchItems) {
		super();
		this.searchItems = searchItems;
	}
	
	
	
	

}
