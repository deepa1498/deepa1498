import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SsComponent } from './ss/ss.component';
import { SkComponent } from './sk/sk.component';


const routes: Routes = [
  
  {path:'Home',component: SkComponent},
  {path:'Place Appointment',component: SsComponent},
  {path:'View Appointment',component: SkComponent},
  {path:'Contact Us',component: SsComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
