import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sk',
  templateUrl: './sk.component.html',
  styleUrls: ['./sk.component.css']
})
export class SkComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
