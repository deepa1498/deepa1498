package com.Emart.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Emart.model.Buyer;
import com.Emart.model.Purchasehistory;


@Repository
public interface PurchasehistoryRepository extends JpaRepository<Purchasehistory, Integer>{

}