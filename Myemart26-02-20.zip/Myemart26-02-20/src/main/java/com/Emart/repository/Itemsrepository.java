package com.Emart.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Emart.model.Items;



@Repository
public interface Itemsrepository extends JpaRepository<Items, Integer>{

	

}
