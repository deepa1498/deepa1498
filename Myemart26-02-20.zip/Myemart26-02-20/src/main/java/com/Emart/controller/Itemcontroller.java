package com.Emart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Emart.model.Cart;
import com.Emart.model.Items;
import com.Emart.service.Cartservice;
import com.Emart.service.Itemservice;

@RestController
public class Itemcontroller {
	@Autowired
	private Itemservice itemservice;
	
	@RequestMapping("/Items")    
	public List<Items> getAllItem()  
	{    
	return itemservice.getAllitem();    
	} 
@GetMapping("")
	
	
	@RequestMapping("/cart")
	public String sayHi() {
		return "Hi Cart-Items";
	}

}
