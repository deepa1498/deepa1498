package com.Emart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.Emart.model.Items;
import com.Emart.repository.Itemsrepository;

public class Itemservice {
    @Autowired
	Itemsrepository itemdao;
	public  List<Items> getAllitem() {
		
		return itemdao.findAll();
	}
		public Items addItem(Items newitems) {
			// TODO Auto-generated method stub


			return itemdao.save(newitems);
	}

}
