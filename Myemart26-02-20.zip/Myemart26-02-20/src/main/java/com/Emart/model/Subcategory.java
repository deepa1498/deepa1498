package com.Emart.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;



@Entity
public class Subcategory implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer subCategoryId;
	private String subCategoryName;
	
	private String briefDetail;
	private String gstpercent;
	@ManyToOne
	@JoinColumn(name="Category_id")
	public Integer getSubCategoryId() {
		return subCategoryId;
	}
	public void setSubCategoryId(Integer subCategoryId) {
		this.subCategoryId = subCategoryId;
	}
	public String getSubCategoryName() {
		return subCategoryName;
	}
	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}
	
	public String getBriefDetail() {
		return briefDetail;
	}
	public void setBriefDetail(String briefDetail) {
		this.briefDetail = briefDetail;
	}
	public String getGstpercent() {
		return gstpercent;
	}
	public void setGstpercent(String gstpercent) {
		this.gstpercent = gstpercent;
	}
	public Subcategory(Integer subCategoryId, String subCategoryName, String briefDetail, String gstpercent) {
		super();
		this.subCategoryId = subCategoryId;
		this.subCategoryName = subCategoryName;
		this.briefDetail = briefDetail;
		this.gstpercent = gstpercent;
	}
	@Override
	public String toString() {
		return "Subcategory [subCategoryId=" + subCategoryId + ", subCategoryName=" + subCategoryName + ", briefDetail="
				+ briefDetail + ", gstpercent=" + gstpercent + "]";
	}
}