package com.Emart.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class Items {
	@Id
@GeneratedValue
	private Integer ItemId;
	@ManyToOne
	@JoinColumn(name="category_id")
	private Category categoryid;
	private int itemprice;
	private String itemname;
	private String description;
	private int stocknumber;
	private String remarks;
	private Subcategory subcategoryid;
	private Seller sellerid;
	public Integer getItemId() {
		return ItemId;
	}
	public void setItemId(Integer itemId) {
		ItemId = itemId;
	}
	public Category getCategoryid() {
		return categoryid;
	}
	public void setCategoryid(Category categoryid) {
		this.categoryid = categoryid;
	}
	public int getItemprice() {
		return itemprice;
	}
	public void setItemprice(int itemprice) {
		this.itemprice = itemprice;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getStocknumber() {
		return stocknumber;
	}
	public void setStocknumber(int stocknumber) {
		this.stocknumber = stocknumber;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Subcategory getSubcategoryid() {
		return subcategoryid;
	}
	public void setSubcategoryid(Subcategory subcategoryid) {
		this.subcategoryid = subcategoryid;
	}
	public Seller getSellerid() {
		return sellerid;
	}
	public void setSellerid(Seller sellerid) {
		this.sellerid = sellerid;
	}
	public Items(Integer itemId, Category categoryid, int itemprice, String itemname, String description,
			int stocknumber, String remarks, Subcategory subcategoryid, Seller sellerid) {
		super();
		ItemId = itemId;
		this.categoryid = categoryid;
		this.itemprice = itemprice;
		this.itemname = itemname;
		this.description = description;
		this.stocknumber = stocknumber;
		this.remarks = remarks;
		this.subcategoryid = subcategoryid;
		this.sellerid = sellerid;
	}
	@Override
	public String toString() {
		return "Items [ItemId=" + ItemId + ", categoryid=" + categoryid + ", itemprice=" + itemprice + ", itemname="
				+ itemname + ", description=" + description + ", stocknumber=" + stocknumber + ", remarks=" + remarks
				+ ", subcategoryid=" + subcategoryid + ", sellerid=" + sellerid + "]";
	}
	

	
}

