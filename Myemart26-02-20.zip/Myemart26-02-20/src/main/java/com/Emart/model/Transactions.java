package com.Emart.model;

import java.io.Serializable;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="transactions")
public class Transactions implements Serializable {
	
	@Id
	 @GeneratedValue(strategy = GenerationType.AUTO)
	private int transaction_id;
	
	@ManyToOne
	@JoinColumn(name="buyer_id")
	@OnDelete(action=OnDeleteAction.CASCADE)
	private Buyer buyer_id;
	
	public Buyer getBuyer_id() {
		return buyer_id;
	}
	public void setBuyer_id(Buyer buyer_id) {
		this.buyer_id = buyer_id;
	}
	private int seller_id;
	private float amount;
	
	private String transaction_type;
	
	@CreationTimestamp
	@Temporal(value= TemporalType.TIMESTAMP )
	@JsonFormat(pattern = "dd-mm-yyyy")
	private Date date;
	
	private String remarks;
	
	
	public int getId() {
		return transaction_id;
	}
	public void setId(int id) {
		this.transaction_id = id;
	}
	
	
	
	public int getSeller_id() {
		return seller_id;
	}
	public void setSeller_id(int seller_id) {
		this.seller_id = seller_id;
	}
	public String getTransaction_type() {
		return transaction_type;
	}
	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
	public Transactions(int transaction_id, int seller_id, float amount, String transaction_type, Date date,
			String remarks) {
		super();
		this.transaction_id = transaction_id;
		
		this.seller_id = seller_id;
		this.amount = amount;
		this.transaction_type = transaction_type;
		this.date = date;
		this.remarks = remarks;
	}
	public Transactions() {
		
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Transactions [transaction_id=" + transaction_id + ", buyer_id=" + buyer_id + ", seller_id=" + seller_id
				+ ", amount=" + amount + ", transaction_type=" + transaction_type + ", date=" + date + ", remarks="
				+ remarks + "]";
	}
	
	


}
