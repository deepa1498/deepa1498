package com.cts.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Cart;
import com.cts.model.Purchasehistory;
import com.cts.model.Transactions;
import com.cts.repository.BuyerRepository;
import com.cts.repository.CartRepository;


@Service
public class Cartservice {
	
	@Autowired
	private CartRepository cartRepository;
	
	public List<Cart> getAllCart() {
		// TODO Auto-generated method stub
		List<Cart> allCart = new ArrayList<Cart>();
		cartRepository.findAll().forEach(allCart::add);
		/* cartItemRepository.findAll().forEach(allCartItems::add); */
		return allCart;
	}
	
	public Cart addCart(Cart newCart) {
		// TODO Auto-generated method stub
		System.out.println("In service");
		return cartRepository.save(newCart);
	}

}
