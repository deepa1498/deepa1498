package com.cts.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity

public class Discount implements Serializable {
	
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int discount_id;
	
	private int discount_code;
	
	private float percentage;
	
	private Date start_date;
	
	private Date end_date;
	
	private String description;
	public int getId() {
		return discount_id;
	}
	public void setId(int id) {
		this.discount_id = id;
	}
	public int getDiscount_code() {
		return discount_code;
	}
	public void setDiscount_code(int discount_code) {
		this.discount_code = discount_code;
	}
	public float getPercentage() {
		return percentage;
	}
	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}
	public Date getStart_date() {
		return start_date;
	}
	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}
	public Date getEnd_date() {
		return end_date;
	}
	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Discount(int discount_id, int discount_code, float percentage, Date start_date, Date end_date,
			String description) {
		super();
		this.discount_id = discount_id;
		this.discount_code = discount_code;
		this.percentage = percentage;
		this.start_date = start_date;
		this.end_date = end_date;
		this.description = description;
	}
	public Discount() {
		
	}
	@Override
	public String toString() {
		return "Discount [discount_id=" + discount_id + ", discount_code=" + discount_code + ", percentage="
				+ percentage + ", start_date=" + start_date + ", end_date=" + end_date + ", description=" + description
				+ "]";
	}
	
	
	


}
