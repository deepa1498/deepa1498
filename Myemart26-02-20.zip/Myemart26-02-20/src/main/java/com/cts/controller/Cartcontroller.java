package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.Cart;
import com.cts.service.Cartservice;


@RestController
public class Cartcontroller {
	
	@Autowired
	private Cartservice cartservice;
	
	@RequestMapping("/cartitems")    
	public List<Cart> getAllItem()  
	{    
	return cartservice.getAllCart();    
	} 
	
	
	
@GetMapping("")
	
	
	@RequestMapping("/cart")
	public String sayHi() {
		return "Hi Cart-Items";
	}

}
