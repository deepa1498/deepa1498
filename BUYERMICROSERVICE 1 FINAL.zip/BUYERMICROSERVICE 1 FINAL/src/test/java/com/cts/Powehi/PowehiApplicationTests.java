package com.cts.Powehi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PowehiApplicationTests {

	@Test
	void contextLoads() {
	}

}
