
package com.buyer.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "cart")
public class Cart  {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int CartId;
	private int itemId;
	private int itemQuantity;
	private String itemDescription;

	
	@ManyToOne
	@JoinColumn(name="buyerId")
	private Buyer buyerId;

	public Cart() {
		
		// TODO Auto-generated constructor stub
	}

	public Cart(int cartId, int itemId, int itemQuantity, String itemDescription, Buyer buyerId) {
		super();
		CartId = cartId;
		this.itemId = itemId;
		this.itemQuantity = itemQuantity;
		this.itemDescription = itemDescription;
		this.buyerId = buyerId;
	}

	public int getCartId() {
		return CartId;
	}

	public void setCartId(int cartId) {
		CartId = cartId;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getItemQuantity() {
		return itemQuantity;
	}

	public void setItemQuantity(int itemQuantity) {
		this.itemQuantity = itemQuantity;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public Buyer getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(Buyer buyerId) {
		this.buyerId = buyerId;
	}

	@Override
	public String toString() {
		return "Cart [CartId=" + CartId + ", itemId=" + itemId + ", itemQuantity=" + itemQuantity
				+ ", itemDescription=" + itemDescription + ", buyerId=" + buyerId + "]";
	}

	public int getNumberofItems() {
		// TODO Auto-generated method stub
		return getNumberofItems();
	}

	 

	

	


	
	
	

}
