
package com.buyer.Entity;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import javax.annotation.Generated;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class Buyer {
	@Id
	@GeneratedValue
	private int BuyerId;
	private String BuyerName;
	private String BuyerPassword;
	private String BuyerEmail;
	private String BuyerMobile;
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	@JsonFormat(pattern = "dd/MM/yyyy")
	private Date createdate;
	
	
	public int getBuyerId() {
		return BuyerId;
	}
	public void setBuyerId(int buyerId) {
		this.BuyerId = buyerId;
	}
	public String getBuyerName() {
		return BuyerName;
	}
	public void setBuyerName(String buyerName) {
		this.BuyerName = buyerName;
	}
	public String getBuyerPass() {
		return BuyerPassword;
	}
	public void setBuyerPass(String buyerPass) {
		this.BuyerPassword = buyerPass;
	}
	public String getBuyerEmail() {
		return BuyerEmail;
	}
	public void setBuyerEmail(String buyerEmail) {
		this.BuyerEmail = buyerEmail;
	}
	public String getBuyerMobile() {
		return BuyerMobile;
	}
	public void setBuyerMobile(String buyerMobile) {
		this.BuyerMobile = buyerMobile;
	}
	public Date getCreatedate() {
		return createdate;
	}
	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}
	
	public Buyer(int buyerId, String buyerName, String buyerPass, String buyerEmail, String buyerMobile,
			Date createdate) {
		super();
		this.BuyerId = buyerId;
		this.BuyerName = buyerName;
		this.BuyerPassword = buyerPass;
		this.BuyerEmail = buyerEmail;
		this.BuyerMobile = buyerMobile;
		this.createdate = createdate;
	}
	public Buyer() {
		
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "BuyerEntity [buyerId=" + BuyerId + ", buyerName=" + BuyerName + ", buyerPass=" + BuyerPassword
				+ ", buyerEmail=" + BuyerEmail + ", buyerMobile=" + BuyerMobile + ", createdate=" + createdate + "]";
	}
	
	
	
	
	
	/*@OneToMany(mappedBy="BuyerEntity", cascade=CascadeType.ALL)
	private List<PurchaseHistoryEntity> purchasehistory;*/
	
	/*@OneToMany(targetEntity=ShoppingCartEntity.class, cascade=CascadeType.ALL)
	private List<ShoppingCartEntity> Shoppingcartt;*/
	
	
	

	
	
	
	
}