/*Items Entity Class*/
package com.buyer.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Items {
	@Id
	@GeneratedValue
	private int itemId;
	@ManyToOne
	@JoinColumn(name="categoryId")
	private Category categoryId;
	private int itemPrice;
	private String itemName;
	private String description;
	private int stockNumber;
	private String remarks;
	@ManyToOne
	@JoinColumn(name="subcategoryId")
	private Subcategory subcategoryId;
	@ManyToOne
	@JoinColumn(name="sellerId")
	private Seller sellerId;
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public Category getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(Category categoryId) {
		this.categoryId = categoryId;
	}
	public int getItemPrice() {
		return itemPrice;
	}
	public void setItemPrice(int itemPrice) {
		this.itemPrice = itemPrice;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getStockNumber() {
		return stockNumber;
	}
	public void setStockNumber(int stockNumber) {
		this.stockNumber = stockNumber;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Subcategory getSubcategoryId() {
		return subcategoryId;
	}
	public void setSubcategoryId(Subcategory subcategoryId) {
		this.subcategoryId = subcategoryId;
	}
	public Seller getSellerId() {
		return sellerId;
	}
	public void setSellerId(Seller sellerId) {
		this.sellerId = sellerId;
	}
	public Items(int itemId, Category categoryId, int itemPrice, String itemName, String description,
			int stockNumber, String remarks, Subcategory subcategoryId, Seller sellerId) {
		super();
		this.itemId = itemId;
		this.categoryId = categoryId;
		this.itemPrice = itemPrice;
		this.itemName = itemName;
		this.description = description;
		this.stockNumber = stockNumber;
		this.remarks = remarks;
		this.subcategoryId = subcategoryId;
		this.sellerId = sellerId;
	}
	public Items() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Items [itemId=" + itemId + ", categoryId=" + categoryId + ", itemPrice=" + itemPrice
				+ ", itemName=" + itemName + ", description=" + description + ", stockNumber=" + stockNumber
				+ ", remarks=" + remarks + ", subcategoryId=" + subcategoryId + ", sellerId=" + sellerId + "]";
	}
	
	
	
}
