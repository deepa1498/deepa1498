
package com.buyer.Entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.buyer.Entity.Buyer;

@Entity
public class Transaction {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int transactionId;
	private String transactionType;
	private Date transactionDate;
	private String transactionRemarks;
	
	@ManyToOne
	@JoinColumn(name="buyerId")
    private Buyer buyerEntity;
	
	@ManyToOne(fetch = FetchType.LAZY,optional = false)
	@JoinColumn(name="buyerId",nullable=false)
	@OnDelete(action = OnDeleteAction.CASCADE)
	
    
	private Buyer buyer;
	

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getRemarks() {
		return transactionRemarks;
	}

	public void setRemarks(String Remarks) {
		this.transactionRemarks = Remarks;
	}

	public Buyer getBuyer() {
		return getBuyer();
	}

	public void setBuyer(Buyer buyer) {
		this.buyer = buyer;
	}

	
	public Transaction() {
		// TODO Auto-generated constructor stub
	}

	public Transaction(int transactionId, String transactionType, Date transactionDate, String transactionRemarks
			) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.transactionRemarks = transactionRemarks;
		
	}

	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", transactionType=" + transactionType
				+ ", transactionDate=" + transactionDate + ", transactionRemarks=" + transactionRemarks + "]";
	}

	
	
}
