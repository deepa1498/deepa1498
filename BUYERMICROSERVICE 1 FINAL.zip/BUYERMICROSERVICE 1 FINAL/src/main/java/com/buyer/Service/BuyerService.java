package com.buyer.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.buyer.Entity.Buyer;
import com.buyer.repository.Buyerrepository;


@Service
public class BuyerService 
{

	@Autowired
	private Buyerrepository buyerrepository;
	
	
	  public List<Buyer> getAllBuyer()
     { 
	          // List<Buyer> buyerList=new ArrayList<>();
		  
	  return buyerrepository.findAll();
	  }
	 

	
	public Buyer addBuyer(Buyer buyer)
	{
	 return	buyerrepository.save(buyer);
		
		
	}


	   
}

