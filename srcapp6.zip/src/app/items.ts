export class Item {

    itemId:number;
    categoryId:number;
    subcategoryId:number;
    price:number;
    itemname:string;
    description:string;
    stockNumber:number;
    remarks:string;
    sellerId:number;

   
}
