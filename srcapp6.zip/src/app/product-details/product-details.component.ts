import { Component, OnInit, Input } from '@angular/core';
import { Item } from '../items';
import { from } from 'rxjs';
import { ProductService } from '../product.service';
import { viewCart } from '../viewcart';



@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
  abc: any;
  constructor(private PService : ProductService ) { }
  itemquantity:number=1;
  @Input() item :Item;
  
cart:viewCart=new viewCart();

//  constructor( ) { }
  ngOnInit(): void {
  }

  onSave(itemId : number)
  {
    console.log("onsave");
    //this.cart.cartId=this.item.categoryId;
 this.cart.itemId=this.item.itemId;
 this.cart.price=this.item.price;
 this.cart.description=this.item.description;
 this.cart.quantity=this.item.stockNumber;
 this.cart.itemname=this.item.itemname;

    this.PService.addToCart(this.cart).subscribe(cart=>{this.cart=cart});
      //error => console.log('erorr'+error));
    
    }

  }
