package com.blog.samples.exception;

public class InvalidAccountRequestException extends RuntimeException {

	private static final long serialVersionUID = 2468434988680850339L;
}
