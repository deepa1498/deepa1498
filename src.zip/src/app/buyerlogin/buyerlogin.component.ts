import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-buyerlogin',
  templateUrl: './buyerlogin.component.html',
  styleUrls: ['./buyerlogin.component.css']
})
export class BuyerloginComponent implements OnInit {
  userName:string;
  password:string;
  constructor(public productservice:ProductService) { }

  ngOnInit(): void {
  }
  //    <!--login()
  // {
  //   console.log("in login method");
  //   const loginPayload = {
  //     username: this.userName,
  //     password: this.password
  // }
  
  //   this.productservice.login(loginPayload).subscribe(data => {
  //     debugger;
  //     if(data.result.token!==null) {
  //   alert("success");
  
  //       window.localStorage.setItem('token', data.result.token);
  //       window.localStorage.setItem('id', data.result.buyerId);
  //       window.localStorage.setItem('username', data.result.username);
  //    console.log(data.result.token);
  //       this.router.navigate(['homepage']);
  //     }else {
  //       //this.invalidLogin = true;
  //       alert("incorrectPasword");
  //     }
  // });
  // }  
} 
