import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewappointmentlistComponent } from './viewappointmentlist.component';

describe('ViewappointmentlistComponent', () => {
  let component: ViewappointmentlistComponent;
  let fixture: ComponentFixture<ViewappointmentlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewappointmentlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewappointmentlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
