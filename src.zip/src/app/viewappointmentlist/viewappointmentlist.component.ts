import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewappointmentlist',
  templateUrl: './viewappointmentlist.component.html',
  styleUrls: ['./viewappointmentlist.component.css']
})
export class ViewappointmentlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
