import { Component, OnInit } from '@angular/core';

import { ProductService } from '../product.service';
import { Item } from '../items';
import { ViewCart } from '../displaycart';

@Component({
  selector: 'app-displaycart',
  templateUrl: './displaycart.component.html',
  styleUrls: ['./displaycart.component.css']
})
export class DisplaycartComponent implements OnInit {
  constructor(private displaycart:ProductService) { }
 
item:Item[];
disCart:ViewCart[];
view:ViewCart=new ViewCart();
cart1:ViewCart=new ViewCart();
i:any
total=0;
  ngOnInit(): void {
      //this.reloading();
  }
// reloading()
// {
//     this.displaycart.displayCartItems().subscribe( Cart => this.cart=Cart);
//     console.log(this.cart);
    
//   }

  increase(cart1:ViewCart){
    if(cart1.noOfItems!=1){
      cart1.noOfItems+=1;
      console.log(cart1.cartId,cart1.itemId,cart1.noOfItems);
      this.displaycart.displayCartItems(cart1).subscribe(view=>this.view=view)
    }
  }
  


  decrease(cart1:ViewCart){
    if(cart1.noOfItems!=1){
      cart1.noOfItems-=1;
      console.log(cart1.cartId,cart1.itemId,cart1.noOfItems);
      this.displaycart.displayCartItems(cart1).subscribe(view=>this.view=view)
    }
  }
  
delete(i:number)
  {
    console.log("delete method"+i);
this.displaycart.deletecartitem(i).subscribe(I=>this.i=I,I=>{alert("Item is deleted.")});
 
  }

//   delete(id:number){
// console.log("delete method"+id);
//   }
  checkout()
  {
  }



}
