import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ViewappointmentlistComponent } from './viewappointmentlist/viewappointmentlist.component';

@NgModule({
  declarations: [
    AppComponent,
    ViewappointmentlistComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
