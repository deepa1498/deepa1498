package com.springboot.jpa.controller;

import com.example.jpa.exception.ResourceNotFoundException;
import com.springboot.jpa.model.Shoppingcart;
import com.springboot.jpa.model.Transactions;
import com.springboot.jpa.repository.BuyerRepository;
import com.springboot.jpa.repository.Comment1Repository;
import com.springboot.jpa.repository.ShoppingcartRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
public class Transactioncontroller {

    @Autowired
    private Comment1Repository comment1Repository;

    @Autowired
    private BuyerRepository postRepository;

    @GetMapping("/posts/{postId}/comments1")
    public Page<Transactions> getAllCommentsByPostId(@PathVariable (value = "postId") Long postId,
                                                Pageable pageable) {
        return Comment1Repository.findByPostId(postId, pageable);
    }

    @PostMapping("/posts/{postId}/comments1")
    public Transactions createComment1(@PathVariable (value = "postId") Long postId,
                                 @Valid @RequestBody Transactions comment1) {
        return postRepository.findById(postId).map(post -> {
            comment1.setPost(post);
            return comment1Repository.save(comment1);
        }).orElseThrow(() -> new ResourceNotFoundException("PostId " + postId + " not found"));
    }

    @PutMapping("/posts/{postId}/comments1/{comment1Id}")
    public Transactions updateComment1(@PathVariable (value = "postId") Long postId,
                                 @PathVariable (value = "comment1Id") Long comment1Id,
                                 @Valid @RequestBody Transactions comment1Request) {
        if(!postRepository.existsById(postId)) {
            throw new ResourceNotFoundException("PostId " + postId + " not found");
        }

        return comment1Repository.findById(comment1Id).map(comment1 -> {
            comment1.setText(comment1Request.getText());
            return comment1Repository.save(comment1);
        }).orElseThrow(() -> new ResourceNotFoundException("Comment1Id " + comment1Id + "not found"));
    }

}
