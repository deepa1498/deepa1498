package com.springboot.jpa.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springboot.jpa.model.Shoppingcart;
import com.springboot.jpa.model.Transactions;

import java.util.Optional;


@Repository
public interface Comment1Repository extends JpaRepository<Transactions, Long> {
    static Page<Transactions> findByPostId(Long postId, Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}
    Optional<Transactions> findByIdAndPostId(Long id, Long postId);
}
