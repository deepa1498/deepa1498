package com.Emart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.Emart.model.Cart;
import com.Emart.model.Transactions;
import com.Emart.service.Cartservice;


@RestController
public class Cartcontroller {
	
	@Autowired
	private Cartservice cartservice;
	
	@GetMapping(value="/cartitems")    
	public List<Cart> getAllItem(@PathVariable("bid")Integer buyerid)  
	{    
	return cartservice.getAllitem(buyerid);    
	} 
	
	
@PostMapping(value = "/{bid}/add",produces="application/json")
public Cart addcartItem(@PathVariable("bid")Integer buyerId,@RequestBody Cart Cartitem)
{
	return Cartitem.get(Cartitem);
	
}
@DeleteMapping(value = "/{cartid}/deletebyid")
public String deletecartitem (@PathVariable("Cartid")Integer buyerId) {
	return cartservice.deleteCartbyItembyId(buyerId);
	
}

@DeleteMapping(value = "/{bid}/deleteall")
public void emptyCart(@PathVariable("bid")Integer buyerid) {
	Cartservice.emptyCart(buyerid);
}
@PutMapping(value = "/{cartid}/update",produces="application/json")
public Cart updateCart(@RequestBody Cart CartItem,@PathVariable("cartid")Integer id) {
	return cartservice.UpdateCart(id);
}
//@PutMapping(value = "/{cartid}/update",produces="application/json")
//public Cart UpdateCart(@RequestBody Cart CartItem,@PathVariable("cartid")Integer id) {
//	return cartservice.updateCart(CartItem,Id);
//}
@PostMapping(value = "/{bid}/checkout",produces="application/json")
public String CheckOut(@RequestBody Transactions transaction,@PathVariable("bid")int buyerid) {
	return cartservice.checkOut(transaction,buyerid);
}

	

}
