export class Cart {
 
 cartId:number;
 itemId:number;
 itemquantity:number;

 itemdescription:String;



}