export class Buyer
{
	
	buyername:string;
	buyerpassword:String ;
	buyeremail:String ;
	buyermobile:number;
     
}