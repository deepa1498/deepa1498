export class Seller{
    sellerName: String;
    sellerpassword:number;
   sellercompanyname: String;
   sellergstin: String;
   companydescription: String;
   selleraddress: String;
  sellerwebsite: String;
   selleremail: String;
    sellermobile:number;
  
     
  }
  
  
  
  
  
  