package com.cts.Ecommerceproject;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Product p = new Product();
		
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			
			System.out.println("1)AddProduct");
			System.out.println("2) FindProductById");
			System.out.println("3) GetAllProductData");
			System.out.println("Enter your choice:");
			int choice = sc.nextInt();
			switch(choice)
			{
			case 1:
			{
				Random rand = new Random();
				int productId1 = rand.nextInt(10000);
				System.out.println("Enter Product Name:");
				
				String ProductName=sc.next();
			
	            System.out.println("Enter ProductDescription:");
				String ProductDescription= sc.next();
				
				System.out.println("Enter ProductPrice:");
				  float ProductPrice =sc.nextFloat();
				 
				  System.out.println("Enter ProductStock:"); 
				  int ProductStock =sc.nextInt();
				  
				 // System.out.println(" --------Categories-------------");
				//  System.out.println("1)Electronics");
				//	System.out.println("2) Mens Clothing");
				//	System.out.println("3) Home Appliances");
					List<String> al=new ArrayList<String>(); 
					al.add("0.Electronics");
					al.add("1.Mens Clothing");
					al.add("2.Home Appliances");
					 System.out.println("Select Category:");
					 System.out.println(al);
					int choice1 = sc.nextInt();
					
					String CategoryName=al.get(choice1);
					/* switch(choice1)
						 {
						 case 1:
							String CategoryName13=al.get(choice1);
							 break;
						 case 2:
							 String CategoryName12=al.get(choice1);
							 break;
						 case 3:
							 String CategoryNaming=al.get(choice1);
							 break;
						 default:
							 System.out.print("not in category");
						 }
					 */
							 int productId=productId1
				 Product p2= new Product(productId,ProductName,ProductDescription,ProductPrice,ProductStock,CategoryName);
				    p.AddProduct(p2);
				break;
			}
			case 2:
			{
				System.out.println("Enter the productid");
				int ProId= sc.nextInt();
				p.FindProductById(ProId);
				break;
			}
			case 3:
			{
				
				p.GetAllProductData();
				break;
			}
			default:
			     System.out.println("not valid");
				
			}
			//sc.close();
		}
		//sc.close();
	}

}
