/*
 * Author:Daggula Maheswara Reddy

 * CreatedDate:12-01-2020
 * Time: 12:54AM
 * POJO CLASS FOR Products that are entered by seller in Ecommerce wesite
 *
 */
package com.cts.Ecommerceproject;

import java.util.ArrayList;
//import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Random;
import java.util.stream.Stream;
//import java.util.*;

public class Product {
	 
	private int ProductId;
	private String ProductName;
	private String ProductDescription;
	private float ProductPrice;
	private int ProductStock;
	private String CategoryName;
	public Product(int productId, String productName, String productDescription, float productPrice,
			int productStock,String CategoryName) {
		super();
		this.ProductId = productId;
		this.ProductName = productName;
		this.ProductDescription = productDescription;
		this.ProductPrice = productPrice;
		this.ProductStock = productStock;
		this.CategoryName = CategoryName;
	}
	
	
	List<Product> ProductList=new ArrayList();
     
	//HashMap<Product, String> map = new HashMap<Product, String>();
	public Product()
	{
		
	}
	public  int getProductId() {
		return ProductId;
	}
	public void setProductId(int productId) {
		
		this.ProductId = productId1;
	}
	public String getProductName() {
		return ProductName;
	}
	public void setProductName(String productName) {
		ProductName = productName;
	}
	public String getProductDescription() {
		return ProductDescription;
	}
	public void setProductDescription(String productDescription) {
		ProductDescription = productDescription;
	}
	public float getProductPrice() {
		return ProductPrice;
	}
	public void setProductPrice(float productPrice) {
		ProductPrice = productPrice;
	}
	public int getProductStock() {
		return ProductStock;
	}
	public void setProductStock(int productStock) {
		ProductStock = productStock;
	}
	public void AddProduct(Product st) {
		ProductList.add(st);
		
		// TODO Auto-generated method stub
		
	}
	public void FindProductById(int ProId) {
		// TODO Auto-generated method stub
	 for(	Product p6: ProductList)
	 {
		 if(p6.getProductId()==ProId)
		 {
			 System.out.println(p6);
		 }
	 }
		
	}
	public void GetAllProductData() {
		//Stream<Product> st=ProductList.stream();
		 ListIterator<Product> itr=ProductList.listIterator();
		//st.forEach(System.out::println);
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
	}
	public String getCategoryName() {
		return CategoryName;
	}
	public void setCategoryName(String categoryName) {
		CategoryName = categoryName;
	}
	@Override
	public String toString() {
		return "Product [ProductId=" + ProductId + ", ProductName=" + ProductName + ", ProductDescription="
				+ ProductDescription + ", ProductPrice=" + ProductPrice + ", ProductStock=" + ProductStock
				+ ", CategoryName=" + CategoryName + "]";
	}
	
	
	
	

}
