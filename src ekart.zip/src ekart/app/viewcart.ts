export class viewCart {
 
 cartId:number;
 itemId:number;
 quantity:number;
 price:number;
 description:String;
  itemname: string;
  noOfItems: number;



}