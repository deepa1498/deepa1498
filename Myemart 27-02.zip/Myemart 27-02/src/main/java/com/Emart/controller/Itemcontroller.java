package com.Emart.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Emart.model.Cart;
import com.Emart.model.Items;
import com.Emart.service.Cartservice;
import com.Emart.service.Itemservice;

@RestController
public class Itemcontroller {
	@Autowired
	private Itemservice itemservice;
	
	@RequestMapping("/Items")    
	public List<Items> getAllItem()  
	{    
	return itemservice.getAllitem();    
	} 
@GetMapping("")
	
	
	@RequestMapping("/items")
	 
	public String items () {
		return "items" ;
}
@PostMapping(value = "/{sid}/update",produces ="application/json")
public Items updateItems(@PathVariable(value="sid") int sid, @RequestBody Items items) {
	
return itemservice.updateItems(sid,items);
}


@GetMapping(value = "/{Itemname}/getallitem")
public List<Items>searchitem(@PathVariable("itemname")String itemname){
	return itemservice.getitembyName(itemname);
}

}
