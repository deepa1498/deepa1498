package com.Emart.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Emart.model.Items;



@Repository
public interface Itemsrepository extends JpaRepository<Items, Integer>{

	@Query(value="SELECT * FROM items_table_seller WHERE items_seller.seller_id_fk=:sellerId",nativeQuery = true)
	public List<Items> findbySellerId (@Param("SellerId") Integer sellerId);
	@Query(value ="DELETE FROM items_table_seller WHERE item_table_seller.seller_id_fk = :Sellerid",nativeQuery= true )
	public void emptyitem(@Param("Sellerid")Integer sellerId,@Param("itemid")Integer SellerId);
	public static List<Items> findItem(String itemname) {
		// TODO Auto-generated method stub
		return Itemsrepository.findItem(itemname);
	}
	
	@Query(value = "from items_entity WHERE itemName like %:itemName",nativeQuery=true)
	public List<Items>finditem(@Param("itemName")String item);
	public static Items update() {
		// TODO Auto-generated method stub
		return Itemsrepository.update();
	}
	public Items save(int sid, Items items);
	
	
	
	}

