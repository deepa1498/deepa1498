package com.Emart.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;


import com.Emart.model.Seller;
import com.Emart.repository.SellerRepository;
@Service
public class Sellerservice {

	@Autowired
	private SellerRepository sellerRepository;
	
	public List<Seller> getAllSellers(){
		List<Seller> sellerlist = new ArrayList<Seller>();
		sellerRepository.findAll().forEach(sellerlist::add);    
		return sellerlist;
	}
	
	public Seller addSeller(Seller seller) {
		return sellerRepository.save(seller);
		
	}
	
	public Optional<Seller> getSeller(@PathVariable Integer sellerId) {
		return sellerRepository.findById(sellerId);
				/*.orElseThrow(()-> new SellerInfoNotFoundException(id));*/
	}
	
	
	public void deleteSeller(int sellerId) {
		// TODO Auto-generated method stub
		sellerRepository.deleteById(sellerId);
	}
	
	// Update BuyersInfo BL
	public void saveOrUpdate(Seller seller) {
		// TODO Auto-generated method stub
		sellerRepository.save(seller);
	}

	



}
