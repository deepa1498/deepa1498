package com.Emart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Emart.model.Items;
import com.Emart.repository.Itemsrepository;
@Repository
public class Itemservice {
    @Autowired
	Itemsrepository itemrepository;
	public  List<Items> getAllitem() {
		
		return itemrepository.findAll();
	}
		public Items addItem(Items newitems) {
			// TODO Auto-generated method stub


			return itemrepository.save(newitems);
			
	}
	


		public List<Items> getitembyName(String itemname) {
			// TODO Auto-generated method stub
			return  itemrepository.finditem(itemname);
		}
		/*public Items updateItems() {
			return Itemsrepository.update(updateitem);
		
		}*/
		public Items updateItems(Items items) {
			
			return  itemrepository.findAll();
			
		}
		
}
