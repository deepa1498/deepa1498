package com.Emart.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.Emart.model.Buyer;
import com.Emart.repository.BuyerRepository;

@Service
public class Buyerservice {

	@Autowired
	private BuyerRepository buyerRepository;
	
	public List<Buyer> getAllBuyers(){
		List<Buyer> buyerslist = new ArrayList<Buyer>();
		buyerRepository.findAll().forEach(buyerslist::add);    
		return buyerslist;
	}
	
	public Buyer addBuyer(Buyer buyer) {
		return buyerRepository.save(buyer);
		
	}
	
	public Optional<Buyer> getBuyer(@PathVariable Integer buyerId) {
		return buyerRepository.findById(buyerId);
				/*.orElseThrow(()-> new BuyerInfoNotFoundException(id));*/
	}
	
	
	public void deleteBuyer(int buyerId) {
		// TODO Auto-generated method stub
		buyerRepository.deleteById(buyerId);
	}
	
	// Update BuyersInfo BL
	public void saveOrUpdate(Buyer buyer) {
		// TODO Auto-generated method stub
		buyerRepository.save(buyer);
	}

	


}
