package com.egg.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.egg.dao.BuyerRepository;
import com.egg.model.Buyer;



@Service
public class Buyerservice implements UserDetailsService {

	@Autowired
	private BuyerRepository buyerRepository;
	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;
	
	public List<Buyer> getAllBuyers(){
		List<Buyer> buyerslist = new ArrayList<Buyer>();
		buyerRepository.findAll().forEach(buyerslist::add);    
		return buyerslist;
	}

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Buyer user = buyerRepository.findByUsername(username);
		if(user == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(), getAuthority());
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}
	
	
	public Buyer addBuyer(Buyer buyer) {
		
		 buyer.setPassword(bcryptEncoder.encode(buyer.getPassword()));
		return buyerRepository.save(buyer);
		
	}
	
	public Optional<Buyer> getBuyer(@PathVariable Integer buyerId) {
		return buyerRepository.findById(buyerId);
				
	}
	
	
	public void deleteBuyer(int buyerId) {
		
		buyerRepository.deleteById(buyerId);
	}
	
	
	public void saveOrUpdate(Buyer buyer) {
		
		buyerRepository.save(buyer);
	}

	public Buyer findOne(String username) {
		
		return buyerRepository.findByUsername(username);
	}

	


}
