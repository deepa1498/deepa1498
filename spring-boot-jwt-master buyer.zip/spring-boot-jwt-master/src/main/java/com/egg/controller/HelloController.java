package com.egg.controller;


import org.springframework.web.bind.annotation.*;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/hello")
public class HelloController {
	@GetMapping

    public String sayhello()
    {return "hello";
		
     }

        

}
