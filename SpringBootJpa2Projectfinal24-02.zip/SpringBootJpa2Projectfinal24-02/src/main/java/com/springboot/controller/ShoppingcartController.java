package com.springboot.controller;

import com.example.jpa.exception.ResourceNotFoundException;
import com.springboot.jpa.model.Shoppingcart;
import com.springboot.jpa.repository.BuyerRepository;
import com.springboot.jpa.repository.ShoppingcartRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
public class ShoppingcartController {

    @Autowired
    private ShoppingcartRepository ShoppingcartRepository;

    @Autowired
    private BuyerRepository BuyerRepository;

    @GetMapping("/Buyer/{BuyerId}/Shoppingcart")
    public Page<Shoppingcart> getAllShoppingcartByBuyerId(@PathVariable (value = "BuyerId") Long BuyerId,
                                                Pageable pageable) {
        return ShoppingcartRepository.findByBuyerId(BuyerId, pageable);
    }

    @PostMapping("/Buyer/{BuyerId}/Shoppingcart")
    public Shoppingcart createShoppingcart(@PathVariable (value = "BuyerId") Long BuyerId,
                                 @Valid @RequestBody Shoppingcart Shoppingcart) {
        return BuyerRepository.findById(BuyerId).map(Buyer -> {
            Shoppingcart.setBuyer(Buyer);
            return ShoppingcartRepository.save(Shoppingcart);
        }).orElseThrow(() -> new ResourceNotFoundException("BuyerId " + BuyerId + " not found"));
    }

    @PutMapping("/Buyer/{BuyerId}/Shoppingcart/{ShoppingcartId}")
    public Shoppingcart updateShoppingcart(@PathVariable (value = "BuyerId") Long BuyerId,
                                 @PathVariable (value = "ShoppingcartId") Long ShoppingcartId,
                                 @Valid @RequestBody Shoppingcart ShoppingcartRequest) {
        if(!BuyerRepository.existsById(BuyerId)) {
            throw new ResourceNotFoundException("BuyerId " + BuyerId + " not found");
        }

        return ShoppingcartRepository.findById(ShoppingcartId).map(Shoppingcart -> {
            Shoppingcart.setText(ShoppingcartRequest.getText());
            return ShoppingcartRepository.save(Shoppingcart);
        }).orElseThrow(() -> new ResourceNotFoundException("ShoppingcartId " + ShoppingcartId + "not found"));
    }

    @DeleteMapping("/Buyer/{BuyerId}/Shoppingcart/{ShioppingcartId}")
    public ResponseEntity<?> deleteShoppingcart(@PathVariable (value = "BuyerId") Long BuyerId,
                              @PathVariable (value = "ShoppingcartId") Long ShoppingcartId) {
        return ShoppingcartRepository.findByIdAndBuyerId(ShoppingcartId, BuyerId).map(Shoppingcart -> {
            ShoppingcartRepository.delete(Shoppingcart);
            return ResponseEntity.ok().build();
        }).orElseThrow(() -> new ResourceNotFoundException("Shoppingcart  not found with id " + ShoppingcartId + " and BuyerId " + BuyerId));
    }
}
