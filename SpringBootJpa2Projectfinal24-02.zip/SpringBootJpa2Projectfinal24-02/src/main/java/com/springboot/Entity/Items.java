package com.springboot.Entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Items implements Serializable
{ 
	@Id
	private int itemid;
    private int categoryid;
    private int subcategoryid;
    private int price;
    private String item_name;
    private  String description;
    private int stock_number;
    private String remarks;
	public int getItemid() {
		return itemid;
	}
	public void setItemid(int itemid) {
		this.itemid = itemid;
	}
	public int getCategoryid() {
		return categoryid;
	}
	public void setCategoryid(int categoryid) {
		this.categoryid = categoryid;
	}
	public int getSubcategoryid() {
		return subcategoryid;
	}
	public void setSubcategoryid(int subcategoryid) {
		this.subcategoryid = subcategoryid;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getItem_name() {
		return item_name;
	}
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getStock_number() {
		return stock_number;
	}
	public void setStock_number(int stock_number) {
		this.stock_number = stock_number;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
	public Items(int itemid, int categoryid, int subcategoryid, int price, String item_name, String description,
			int stock_number, String remarks) {
		super();
		this.itemid = itemid;
		this.categoryid = categoryid;
		this.subcategoryid = subcategoryid;
		this.price = price;
		this.item_name = item_name;
		this.description = description;
		this.stock_number = stock_number;
		this.remarks = remarks;
		
	}
	@Override
	public String toString() {
		return "Items [itemid=" + itemid + ", categoryid=" + categoryid + ", subcategoryid=" + subcategoryid
				+ ", price=" + price + ", item_name=" + item_name + ", description=" + description + ", stock_number="
				+ stock_number + ", remarks=" + remarks + "]";
	}
    
    
}
