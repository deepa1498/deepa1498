package com.springboot.service;

public class Shoppingcartservice {

}
