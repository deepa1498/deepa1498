package com.springboot.Repository;

public class Purchaserepository {

}
