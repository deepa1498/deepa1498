package com.buyer.repository;

public interface Transactionrepository {

}
