/*SubCategory Entity Class*/
package com.buyer.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Subcategory 
{
	@Id	
	private int subcategoryId;
	private String subcategoryName;
	private String breifDetails;
	private String gstPercent;
	
	@ManyToOne
	@JoinColumn(name="categoryId")
    private Category category_Id;

	public int getSubcategoryId() {
		return subcategoryId;
	}

	public void setSubcategoryId(int subcategoryId) {
		this.subcategoryId = subcategoryId;
	}

	public String getSubcategoryName() {
		return subcategoryName;
	}

	public void setSubcategoryName(String subcategoryName) {
		this.subcategoryName = subcategoryName;
	}

	public String getSubbreifDetails() {
		return breifDetails;
	}

	public void setSubbreifDetails(String subbreifDetails) {
		this.breifDetails = subbreifDetails;
	}

	public String getGstPercent() {
		return gstPercent;
	}

	public void setGstPercent(String gstPercent) {
		this.gstPercent = gstPercent;
	}

	/*public CategoryEntity getParent() {
		return parent;
	}

	public void setParent(CategoryEntity parent) {
		this.parent = parent;
	}

	public SubCategoryEntity() {
		// TODO Auto-generated constructor stub
	}*/

	public Subcategory(int subcategoryId, String subcategoryName, String breifDetails, String gstPercent
			) {
		super();
		this.subcategoryId = subcategoryId;
		this.subcategoryName = subcategoryName;
		this.breifDetails = breifDetails;
		this.gstPercent = gstPercent;
		
	}

	@Override
	public String toString() {
		return "SubCategoryEntity [subcategoryId=" + subcategoryId + ", subcategoryName=" + subcategoryName
				+ ", breifDetails=" + breifDetails + ", gstPercent=" + gstPercent + "]";
	}

	
	
	
	
	

}
