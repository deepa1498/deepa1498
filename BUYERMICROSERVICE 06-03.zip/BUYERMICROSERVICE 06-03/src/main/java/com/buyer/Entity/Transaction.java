/*Transaction Entity Class*/
package com.buyer.Entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.buyer.Entity.Buyer;

@Entity
public class Transaction {
	
	@Id
	@GeneratedValue
	private int transactionId;
	private String transactionType;
	private Date transactionDate;
	private String Remarks;
	
	@ManyToOne
	@JoinColumn(name="buyerId")
    private Buyer buyerEntity;
	
	@ManyToOne
	@JoinColumn(name="sellerId")
    private Seller sellerEntity;

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getRemarks() {
		return Remarks;
	}

	public void setRemarks(String Remarks) {
		this.Remarks = Remarks;
	}

	/*public BuyerEntity getBuyerEntity() {
		return buyerEntity;
	}

	public void setBuyerEntity(BuyerEntity buyerEntity) {
		this.buyerEntity = buyerEntity;
	}

	public SellerEntity getSellerEntity() {
		return sellerEntity;
	}

	public void setSellerEntity(SellerEntity sellerEntity) {
		this.sellerEntity = sellerEntity;
	}*/

	public Transaction() {
		// TODO Auto-generated constructor stub
	}

	public Transaction(int transactionId, String transactionType, Date transactionDate, String transactionRemarks
			) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.Remarks = Remarks;
		
	}

	@Override
	public String toString() {
		return "TransactionEntity [transactionId=" + transactionId + ", transactionType=" + transactionType
				+ ", transactionDate=" + transactionDate + ", Remarks=" + Remarks + "]";
	}

	
	
}
