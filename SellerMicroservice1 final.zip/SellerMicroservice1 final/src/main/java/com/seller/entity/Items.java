package com.seller.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.springframework.beans.factory.annotation.Autowired;
@Entity
public class Items implements Serializable {
	@Id
@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer ItemId;
	
	private float itemprice;
	private String itemname;
	private String description;
	private int stocknumber;
private String remarks;
private int subcategoryid;
private int cart;
private int categoryid;
@ManyToOne
@JoinColumn(name="seller_key")
private Seller sellerid;

public Items() {}
public Items(int categoryid) {
	super();
	this.categoryid = categoryid;
}
public int getCategoryid() {
	return categoryid;
}
public void setCategoryid(int categoryid) {
	this.categoryid = categoryid;
}
public Integer getItemId() {
	return ItemId;
}
public void setItemId(Integer itemId) {
	ItemId = itemId;
}
public float getItemprice() {
	return itemprice;
}
public void setItemprice(float itemprice) {
	this.itemprice = itemprice;
}
public String getItemname() {
	return itemname;
}
public void setItemname(String itemname) {
	this.itemname = itemname;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public int getStocknumber() {
	return stocknumber;
}
public void setStocknumber(int stocknumber) {
	this.stocknumber = stocknumber;
}
public String getRemarks() {
	return remarks;
}
public void setRemarks(String remarks) {
	this.remarks = remarks;
}
public int getSubcategoryid() {
	return subcategoryid;
}
public void setSubcategoryid(int subcategoryid) {
	this.subcategoryid = subcategoryid;
}


public Seller getSellerid() {
	return sellerid;
}
public void setSellerid(Seller sellerid) {
	this.sellerid = sellerid;
}

	
public Items(Integer itemId, float itemprice, String itemname, String description, int stocknumber, String remarks,
		int subcategoryid, int cart, int categoryid, Seller sellerid) {
	super();
	ItemId = itemId;
	this.itemprice = itemprice;
	this.itemname = itemname;
	this.description = description;
	this.stocknumber = stocknumber;
	this.remarks = remarks;
	this.subcategoryid = subcategoryid;
	this.cart = cart;
	this.categoryid = categoryid;
	this.sellerid = sellerid;
}
@Override
public String toString() {
	return "Items [ItemId=" + ItemId + ", itemprice=" + itemprice + ", itemname=" + itemname + ", description="
			+ description + ", stocknumber=" + stocknumber + ", remarks=" + remarks + ", subcategoryid=" + subcategoryid
			+ ", cart=" + cart + ", categoryid=" + categoryid + ", sellerid=" + sellerid + "]";
}





}
	