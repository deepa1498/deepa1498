package com.example.jpa.controller;

import com.example.jpa.exception.ResourceNotFoundException;
import com.example.jpa.model.Shoppingcart;
import com.example.jpa.model.Comment1;
import com.example.jpa.repository.Comment1Repository;
import com.example.jpa.repository.ShoppingcartRepository;
import com.example.jpa.repository.BuyerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
public class Comment1Controller {

    @Autowired
    private Comment1Repository comment1Repository;

    @Autowired
    private BuyerRepository postRepository;

    @GetMapping("/posts/{postId}/comments1")
    public Page<Comment1> getAllCommentsByPostId(@PathVariable (value = "postId") Long postId,
                                                Pageable pageable) {
        return Comment1Repository.findByPostId(postId, pageable);
    }

    @PostMapping("/posts/{postId}/comments1")
    public Comment1 createComment1(@PathVariable (value = "postId") Long postId,
                                 @Valid @RequestBody Comment1 comment1) {
        return postRepository.findById(postId).map(post -> {
            comment1.setPost(post);
            return comment1Repository.save(comment1);
        }).orElseThrow(() -> new ResourceNotFoundException("PostId " + postId + " not found"));
    }

    @PutMapping("/posts/{postId}/comments1/{comment1Id}")
    public Comment1 updateComment1(@PathVariable (value = "postId") Long postId,
                                 @PathVariable (value = "comment1Id") Long comment1Id,
                                 @Valid @RequestBody Comment1 comment1Request) {
        if(!postRepository.existsById(postId)) {
            throw new ResourceNotFoundException("PostId " + postId + " not found");
        }

        return comment1Repository.findById(comment1Id).map(comment1 -> {
            comment1.setText(comment1Request.getText());
            return comment1Repository.save(comment1);
        }).orElseThrow(() -> new ResourceNotFoundException("Comment1Id " + comment1Id + "not found"));
    }

}
