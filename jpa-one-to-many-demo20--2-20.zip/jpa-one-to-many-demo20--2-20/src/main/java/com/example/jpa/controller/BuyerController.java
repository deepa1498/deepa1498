package com.example.jpa.controller;

import com.example.jpa.exception.ResourceNotFoundException;
import com.example.jpa.model.Buyer;
import com.example.jpa.repository.BuyerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
public class BuyerController {

    @Autowired
    private BuyerRepository BuyerRepository;

    @GetMapping("/Buyer")
    public Page<Buyer> getAllPosts(Pageable pageable) {
        return BuyerRepository.findAll(pageable);
    }

    @PostMapping("/Buyer")
    public Buyer createBuyer(@Valid @RequestBody Buyer Buyer ) {
        return BuyerRepository.save(Buyer);
    }

    @PutMapping("/Buyer/{BuyerId}")
    public Buyer updateBuyer(@PathVariable Long BuyerId, @Valid @RequestBody Buyer BuyerRequest) {
        return BuyerRepository.findById(BuyerId).map(Buyer -> {
        	Buyer.setTitle(BuyerRequest.getTitle());
        	Buyer.setDescription(BuyerRequest.getDescription());
        	Buyer.setContent(BuyerRequest.getContent());
            return BuyerRepository.save(Buyer);
        }).orElseThrow(() -> new ResourceNotFoundException("BuyerId " + BuyerId + " not found"));
    }

    @DeleteMapping("/Buyer/{BuyerId}")
    public ResponseEntity<?> deleteBuyer(@PathVariable Long BuyerId) {
        return BuyerRepository. findById(BuyerId).map(Buyer -> {
        	BuyerRepository.delete(Buyer);
            return ResponseEntity.ok().build();
        }).orElseThrow(() -> new ResourceNotFoundException("BuyerId " + BuyerId + " not found"));
    }


}
